from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import hrreg,PostJob,AppliedStudent
from webadmin.models import CourseData

def index(request):
	if request.method =='POST':
		check = hrreg.objects.filter(Email=request.POST['txtemail'],Password=request.POST['txtpass']).values_list('Status',flat=True)
		if check.count()>0:
			c = check[0]
			if c=='1':
				request.session['uemail']= request.POST['txtemail']
				return redirect('hrdash')
			else:
				return render(request,'employer/index.html',{"notapprove":'Not Approve By Admin'})

		else:
			return render(request,'employer/index.html',{'invalid':"Invalid"})


	return render(request,'employer/index.html')

def register(request):
	if request.method=='POST':
		email = hrreg.objects.filter(Email=request.POST['email'])
		if email.count()>0:
			return render(request,'employer/register.html',{'already_registered':"Email Id is Already Registered",'emailid':request.POST['email']})
		else:
			record = hrreg(Full_Name=request.POST['name'],Company_Name=request.POST['cname'],
				Email=request.POST['email'],Password=request.POST['password'],Mobile=request.POST['mobile'],Status=0)
			record.save()
			return redirect('/employer')
	return render(request,'employer/register.html')

def login(request):
	if request.method =='POST':
		check = hrreg.objects.filter(Email=request.POST['txtemail'],Password=request.POST['txtpass']).values_list('Status',flat=True)
		if check.count()>0:
			c = check[0]
			if c=='1':
				request.session['uemail']= request.POST['txtemail']
				return redirect('hrdash')
			else:
				return render(request,'employer/login.html',{"notapprove":'Not approve'})

		else:
			return render(request,'employer/login.html',{'invalid':"Invalid"})

	return render(request,'employer/login.html')

def hrdash(request):
	if request.session.has_key('uemail'):
		uemail = request.session['uemail']
		return render(request,'employer/hrdash.html')
	else:
		return redirect('/employer')

def postjob(request):
	if request.session.has_key('uemail'):
		uemail = request.session['uemail']
		tech = CourseData.objects.all().order_by('Course_Name')
		hr_details = hrreg.objects.filter(Email=uemail)
		if request.method =='POST':
			post_job_data = PostJob(Technology=request.POST['technology'],Job_Description=request.POST['desc'],Experience=request.POST['exp'],
				Company_Name=request.POST['cname'],Company_Email=request.POST['cemail'],Company_Contact=request.POST['cnumber'],
				Post_Date=request.POST['postdt'],Expiry_Date=request.POST['expdt'],Status=0,role='employer')
			post_job_data.save()

			return render(request,'employer/postjob.html',{'tech':tech,'upload':"Job Posted, Wait For Admin Approval ",'hr_details':hr_details})

		return render(request,'employer/postjob.html',{'tech':tech,'hr_details':hr_details})
	else:
		return redirect('/employer')


def appliedstudent(request):
	if request.session.has_key('uemail'):
		uemail = request.session['uemail']
		#cn = hrreg.objects.filter(Email=uemail).values_list('Company_Name',flat=True)
		#com_name= cn[0]
		
		students = AppliedStudent.objects.all()
		if request.method == 'POST':
			from_date = request.POST['from_date']
			to_date = request.POST['to_date']
			#res = AppliedStudent.objects.filter(apply_dt__range=[from_date,to_date])
			#res = AppliedStudent.objects.filter(apply_dt__gte=from_date,apply_dt__lte=to_date)
			res = AppliedStudent.objects.raw('SELECT id,student_name,student_number,technology,email,resume,apply_dt FROM employer_appliedstudent WHERE apply_dt BETWEEN "'+from_date+'" and "'+to_date+'"')
			print(res)
			return render(request,'employer/appliedstudent.html',{'students':res,'uemail':uemail})
	
	
		return render(request,'employer/appliedstudent.html',{'students':students,'uemail':uemail})
	else:
		return redirect('/employer')

	
def logout(request):
	del request.session['uemail']
	return redirect('/employer')


def view_posted_job(request):
	if request.session.has_key('uemail'):
		uemail = request.session['uemail']
		jobs_data = PostJob.objects.filter(Company_Email=uemail)
		return render(request,'employer/view_posted_job.html',{'jobs_data':jobs_data})

	else:
		return redirect('/employer')


def jobedit(request):
	if request.session.has_key('uemail'):
		uemail = request.session['uemail']
		jid = request.GET['q']
		jobs_data = PostJob.objects.get(pk=jid)
		technology_data = CourseData.objects.all().order_by('Course_Name')
		
		if request.method == 'POST':
			if request.POST.get('update'):
				edit_jobs_data =PostJob.objects.get(pk=request.POST['hiddenid'])
				edit_jobs_data.Technology = request.POST['technology']
				edit_jobs_data.Job_Description = request.POST['desc']
				edit_jobs_data.Experience = request.POST['exp']
				edit_jobs_data.Post_Date = request.POST['postdt']
				edit_jobs_data.Expiry_Date = request.POST['expdt']
				edit_jobs_data.save()
				return redirect('view_posted_job')
		
		return render(request,'employer/jobedit.html',{'jobs_data':jobs_data,'tech':technology_data})

	else:
		return redirect('/employer')

def jobdelete(request):
	jobs_data = PostJob.objects.get(pk=request.GET['q'])
	if request.method=='POST':
		if request.POST.get('yes'):
			jobs_data.delete()
			return redirect('view_posted_job')
		else:
			return redirect('view_posted_job')
	return render(request,'employer/jobdelete.html',{'jobs_data':jobs_data})
