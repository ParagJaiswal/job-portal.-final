from django.urls import path
from .import views

urlpatterns = [
	path('',views.index,name='index'),
	path('register',views.register,name='register'),
	path('login',views.login,name='login'),
	path('hrdash',views.hrdash,name='hrdash'),
	path('postjob',views.postjob,name='postjob'),
	path('appliedstudent',views.appliedstudent,name='appliedstudent'),
	path('logout',views.logout,name='logout'),
	path('view_posted_job',views.view_posted_job,name='view_posted_job'),
	path('jobedit',views.jobedit,name='jobedit'),
	path('jobdelete',views.jobdelete,name='jobdelete'),
]