from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import StudentReg
from webadmin.models import CourseData,StudentRecord,BranchMaster
from employer.models import PostJob,AppliedStudent
import datetime
from django.conf import settings
from django.core.files.storage import FileSystemStorage



def index(request):
	if request.method =='POST':
		chk = StudentReg.objects.filter(Email = request.POST['txtemail'],Password=request.POST['txtpass']).values_list('Status',flat=True)
		

		if chk.count()>0:
			p = chk[0] # Through Dictionary will iterate the value of Status because of above valu_list

			
			if p == '1':
				request.session['user'] = request.POST['txtemail']
				
				return redirect('stuhome')
			else:
						
				
				return render(request,'studentapp/index.html',{"notapprove":"Profile is not approve,contact to admin"})
			
		else:
			
			return render(request,'studentapp/index.html',{"invalid":'Incorrect User ID and Password'})

	
	return render(request,'studentapp/index.html')

def register(request):
	branch =BranchMaster.objects.all().order_by('branch_name')
	if request.method == 'POST':
		 
		chk = StudentReg.objects.filter(Email=request.POST['txtemail'])
		if chk.count()>0:
			return render(request,'studentapp/register.html',{'already_registered':"Email Id Is Already Registered",'branch':branch,'emailid':request.POST['txtemail']})
		else:
			registeredstudent = StudentReg(Email=request.POST['txtemail'],Password=request.POST['txtpass'],Mobile=request.POST['txtmobile'],Branch=request.POST['txtbranch'],Status=0)
			registeredstudent.save()
			return redirect('/studentapp')


	return render(request,'studentapp/register.html',{'branch':branch})
def login(request):
	if request.method =='POST':
		chk = StudentReg.objects.filter(Email = request.POST['txtemail'],Password=request.POST['txtpass']).values_list('Status',flat=True)
		

		if chk.count()>0:
			p = chk[0] # Through Dictionary will iterate the value of Status because of above valu_list

			
			if p == '1':
				request.session['user'] = request.POST['txtemail']
				
				return redirect('stuhome')
			else:
						
				
				return render(request,'studentapp/login.html',{"notapprove":"Profile is not approve,contact to admin"})
			
		else:
			
			return render(request,'studentapp/login.html',{"invalid":'Incorrect User ID and Password'})

	return render(request,'studentapp/login.html')

def stuhome(request):
	if request.session.has_key('user'):
		user = request.session['user']
		show =StudentRecord.objects.filter(Email=user)
		
		s = StudentRecord.objects.filter(Email=user).values_list('Full_Name',flat=True)
		
		if s.count()>0:
			n= s[0]
			
			
		

			return render(request,'studentapp/stuhome.html',{'show':show,'user':n})
		else:
			return render(request,'studentapp/stuhome.html',{'user':user,'s':s,'show':show})
	else:
		return redirect('/studentapp')
def addprofile(request):
	if request.session.has_key('user'):
		user =request.session['user']
		record = StudentReg.objects.get(Email=user)
		coursedata = CourseData.objects.all().order_by('Course_Name')
		if request.method == 'POST':
			if request.POST.get('regbtn'):
				strecord = StudentRecord(Full_Name=request.POST['txtname'],Mobile=request.POST['txtmobile'],Email=request.POST['txtemail'],Course=request.POST['course'],
					Description=request.POST['description'],Branch=request.POST['txtbranch'],Passing_Year=request.POST['txtpassingyear'],Secondary_Percentage=request.POST['txtsec'],
					Higher_Secondary_Percentage=request.POST['txthigher-sec'],Graduation_Stream=request.POST['txtgraduation-stream'],Graduation_Percentage=request.POST['txtgraduation-percentage'],
					Post_Graduation_Stream=request.POST['txtpg-stream'],Post_Graduation_Percentage=request.POST['txtpg-percentage'],Other_Certification=request.POST['txtother-qualification'])

				strecord.save()
				return redirect('stuhome')
		return render(request,'studentapp/addprofile.html',{'coursedata':coursedata,'record':record})
	else:
		return redirect('/studentapp')

def stuedit(request):
	if request.session.has_key('user'):
		selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
		if request.method=='POST':
			if request.POST.get('update'):
				selectedstu.Full_Name=request.POST['txtname']
				selectedstu.Mobile=request.POST['txtmobile']
				selectedstu.Email=request.POST['txtemail']
				selectedstu.Course=request.POST['txtcourse']
				selectedstu.Description=request.POST['txtarea']
				selectedstu.Branch=request.POST['txtbranch']
				selectedstu.Passing_Year=request.POST['txtpassing_year']
				selectedstu.Secondary_Percentage=request.POST['txtsecondarypercentage']
				selectedstu.Higher_Secondary_Percentage=request.POST['txthighsecondarypercentage']
				selectedstu.Graduation_Stream=request.POST['graduationstream']
				selectedstu.Graduation_Percentage=request.POST['graduationpercentage']
				selectedstu.Post_Graduation_Stream=request.POST['post-graduationstream']
				selectedstu.Post_Graduation_Percentage=request.POST['post-graduationpercentage']
				selectedstu.Other_Certification=request.POST['txtother-certification']
				selectedstu.save()
				return redirect('stuhome')
			else:
				return redirect('stuhome')
		return render(request,'studentapp/stuedit.html',{'stuedit':selectedstu})
	else:
		return redirect('/studentapp')

def studel(request):
	if request.session.has_key('user'):
		selectedstu = StudentRecord.objects.get(pk=request.GET['id'])
		if request.method== 'POST':
			if request.POST.get('yes'):
				selectedstu.delete()
				return redirect('stuhome')
			else:
				return redirect('stuhome')
			
		return render(request,'studentapp/studel.html',{'selectedstu':selectedstu})
	else:
		return redirect('/studentapp')

def alljobs(request):
		
		current_date= datetime.datetime.today().strftime("%Y-%m-%d")
		#print(current_date)
		all_jobs_record = PostJob.objects.filter(Status=1,Expiry_Date__gte=current_date)
		#current_date= datetime.datetime.today().strftime("%d-%m-%y")
		
		current_date2 = datetime.datetime.today()
		date_plus_one = current_date2.date() + datetime.timedelta(days=1) 
		#print(date_plus_one)
		deletejob = PostJob.objects.filter(Status=1,Expiry_Date__lte=date_plus_one)
		deletejob.delete()


		

		
		
		return render(request,'studentapp/alljobs.html',{'all_jobs_record':all_jobs_record,"current_date":current_date})

	
def techjobs(request):
	if request.session.has_key('user'):
		user = request.session['user']
		sr = StudentRecord.objects.filter(Email=user).values_list('Course',flat=True)
		try:

			tech = sr[0]
		except IndexError:
			#return HttpResponse('<h1>Please Add Your Profile First</h1>')
			return render(request,'studentapp/techjob_index_error.html')
		current_date= datetime.datetime.today().strftime("%Y-%m-%d")
		job_as_per_tech = PostJob.objects.filter(Technology=tech,Status=1,Expiry_Date__gte=current_date)

		current_date2 = datetime.datetime.today()
		date_plus_one = current_date2.date() + datetime.timedelta(days=1) 
		#print(date_plus_one)
		deletejob = PostJob.objects.filter(Status=1,Expiry_Date__lte=date_plus_one)
		deletejob.delete()

		

		return render(request,'studentapp/techjobs.html',{'job_as_per_tech':job_as_per_tech,"current_date":current_date})
	else:
		return redirect('/studentapp')

def applyjob(request):
	if request.session.has_key('user'):
		technology = CourseData.objects.all()
		user = request.session['user']
		student_details = StudentRecord.objects.filter(Email=user)
		
		
		if request.method=='POST' and request.FILES['resumefile']:
			 post_job_id = request.GET['q']
			 #print(post_job_id)
			 uploaded_resume = request.FILES['resumefile']
			 fs = FileSystemStorage()
			 filename = fs.save(uploaded_resume.name,uploaded_resume)
			 url = fs.url(filename)
			 today_date=datetime.datetime.today()

			 data = AppliedStudent(student_name=request.POST['name'],student_number=request.POST['number'],resume=url,job_applied_id=post_job_id,technology=request.POST['course'],email=request.POST['email'],apply_dt=today_date)
			 data.save()

			 return render(request,'studentapp/applyjob.html',{'technology':technology,'student_details':student_details,"submit":'Details Submitted'})

		#hr_company = PostJob.objects.filter(Company_Name=post_job_id)
		#print(hr_company)
		return render(request,'studentapp/applyjob.html',{'technology':technology,'student_details':student_details})
	else:
		return redirect(login)
def logout(request):
	del request.session['user']

	return redirect('/studentapp')