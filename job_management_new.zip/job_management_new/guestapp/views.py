from django.shortcuts import render
from employer.models import PostJob
import datetime

def index(request):
	return render(request,'guestapp/index.html')

def ajaxjob(request):
	detail = request.GET['v']
	date = datetime.datetime.today()
	current_date = date.strftime("%Y-%m-%d")
	print(current_date)
	jobs = PostJob.objects.filter(Technology__contains=detail,Expiry_Date__gte=current_date)
	current_date2 = datetime.datetime.today()
	date_plus_one = current_date2.date() + datetime.timedelta(days=1) 
	deletejob = PostJob.objects.filter(Status=1,Expiry_Date__lte=date_plus_one)
	deletejob.delete()
	
	return render(request,'guestapp/loaddata.html',{'jobs':jobs})

def contact_us(request):
	return render(request,'guestapp/contact_us.html')

def about(request):
	return render(request,'guestapp/about.html')
