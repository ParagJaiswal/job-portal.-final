from django.urls import path
from . import views

urlpatterns = [
	path('',views.index,name='index'),
	path('ajaxjobs',views.ajaxjob,name='ajaxjob'),
	path('contact_us',views.contact_us,name='contact_us'),
	path('about',views.about,name='about'),
]